# TOPSIS Python Package

## Installation
pip install Topsis-Vandana-102303443

## Usage
topsis input.csv "1,1,1,1" "+,+,-,+" output.csv

## Input Format
First column: Alternatives  
Remaining columns: Criteria values

## Output
CSV file with Topsis Score and Rank
